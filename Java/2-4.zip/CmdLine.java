class CmdLine{
  public static void main(String[] args){
    System.out.println("args[0]�F" + args[0]);
    System.out.println("args[1]�F" + args[1]);
    System.out.println("args.length�F" + args.length);
  }
}
